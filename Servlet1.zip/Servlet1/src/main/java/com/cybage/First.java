package com.cybage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class First extends HttpServlet {
    
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		out.print("<!DoctType Html>");
		out.print("<html>");
		out.print("<head>");
		out.print("<title> title of the page</title>");
		out.print("<head>");
		out.print("<body>");
		out.print("<h1>Welcome to servlet programming</h1>");
		out.print("<body>");
		out.print("<html>");
		out.print(request.getContextPath());
		out.print(request.getLocalPort());
		out.print(request.getProtocol());
		//out.print("reading url data"+request.getParameter("name"));
		out.print("Welcome "+request.getParameter("un"));
		//request.getRequestDispatcher("second").forward(request,response);
		request.getRequestDispatcher("second").include(request,response);
		//if want to redirect to external url(outside current application)
		//response.sendRedirect("http://www.cybage.com");
		
		
		
	}
	
}
