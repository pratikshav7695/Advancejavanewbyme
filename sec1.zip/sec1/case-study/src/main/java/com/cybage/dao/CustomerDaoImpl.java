package com.cybage.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import com.cybage.model.Batch;
import com.cybage.model.Enrollment;
import com.cybage.model.Plans;
import com.cybage.model.Sports;
import com.cybage.model.Users;
import com.cybage.model.Users1;



public class CustomerDaoImpl implements CustomerDaoI {
	public Boolean validateuser(String name, String pass) throws Exception {
		// TODO Auto-generated method stub
		boolean st =false;
		try {
		String sql = "select Username,Password from users where username = ? and password=?";
		Connection con = DbUtil.getConnection();		
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, name);
		ps.setString(2, pass);
		ResultSet rs= ps.executeQuery();
		st = rs.next();
		return st;
		}
		catch(Exception e) {
            e.printStackTrace();
        }
        return st; 
		
}

	public Boolean insertuser(String username, String password, String role, String address, String Phone, String email)
			throws Exception {
		String sql = "insert into users (username,password,role,address,Phone,email)values(?, ?, ?, ?,?,?)";
		Connection con = DbUtil.getConnection();		//new object
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1,username);
		ps.setString(2, password);
		ps.setString(3,role);
		ps.setString(4,address);
		ps.setString(5,Phone);
		ps.setString(6,email);

		if(ps.executeUpdate() == 1) {
			con.commit();			
			con.close();  
			return true;
		}
		else{ 
			con.rollback();
			ps.close(); 
			con.close(); 
			return false;
		}
	}
	public List<Sports> displaysports() throws Exception{
		String sql = "select * from sports";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Sports> sports = new ArrayList<Sports>();
		while(rs.next()) {
			sports.add(new Sports(rs.getInt(1), rs.getString(2)));
		
		}
		return sports;
	}
	public List<Plans> displayplans() throws Exception{
		String sql = "select * from plans";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Plans> Plans = new ArrayList<Plans>();
		while(rs.next()) {
			Plans.add(new Plans(rs.getInt(1), rs.getInt(2),rs.getString(3),rs.getDouble(4),rs.getInt(5)));;
		}
		return Plans;
	}
	public List<Batch> displayBatches() throws Exception{
		String sql = "select * from batch";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Batch> batch = new ArrayList<Batch>();
		while(rs.next()) {
			batch.add(new Batch(rs.getInt(1), rs.getDate(2),rs.getDate(3),rs.getInt(4),rs.getInt(5)));;
		}
		for(Batch b:batch)
		{
			System.out.println("batches"+batch);
		}
			
	
		return batch;
	}

	
	public List<Batch> displayBatchesbyplan(int planid) throws Exception{
		String sql = "select * from batch where planid=?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setInt(1,planid);
		ResultSet rs = ps.executeQuery();
		List<Batch> batch = new ArrayList<Batch>();
		while(rs.next()) {
			batch.add(new Batch(rs.getInt(1), rs.getDate(2),rs.getDate(3),rs.getInt(4),rs.getInt(5)));;
		}
		for(Batch b:batch)
		{
			System.out.println("batches"+batch);
		}
			
	
		return batch;
	}
	public List<Enrollment> displayEnroll(String username) throws Exception {
		String sql = "select * from enrollment where username = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, username);
		ResultSet rs = ps.executeQuery();
		
		List<Enrollment> batch = new ArrayList<Enrollment>();
		while(rs.next()) {
			batch.add(new Enrollment(rs.getInt(1), rs.getInt(2), rs.getDate(3),  rs.getDate(4), rs.getString(5)));
		}
		return batch;
	
	}

	public Users1 viewuser(String username) throws Exception {
		String sql = "select * from users where username = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, username);
		ResultSet rs = ps.executeQuery();

		Users1 user = null;
		if(rs.next()) {
			user = new Users1 (rs.getInt(1), rs.getString(2), rs.getString(3),  rs.getString(4), rs.getString(5),rs.getString(6), rs.getString(7));
		}
		System.out.println(user);
		return user;
	}
	
	public boolean updateEnrollment(LocalDate startdate,LocalDate Enddate,String username)  throws Exception{
		String sql = "update Enrollment set startDate= ? , endDate = ? where username = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		Date sdate = (Date) Date.from(startdate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date edate = (Date) Date.from(Enddate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		ps.setDate(1, sdate);
		ps.setDate(2, edate);;
		ps.setString(3, username);
		if(ps.executeUpdate() == 1) {
			 
			return true;
		}
		else{ 
			return false;
		}
	}
	
	
	public boolean updateuser(String userName, String address, String password, String phone, String email)
			throws SQLException, Exception {
		String sql = "update users set username= ? ,address=?, password = ?,phone = ?,email = ? where username= ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userName);
		ps.setString(2, address);
		ps.setString(3, password);
		ps.setString(4, phone);
		ps.setString(5, email);
		ps.setString(6, userName);
		if (ps.executeUpdate() == 1) {
			return true;
		} else {
			return false;
		}
	}

	public int updateUser(Users1 user) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}
	

	
	
}
