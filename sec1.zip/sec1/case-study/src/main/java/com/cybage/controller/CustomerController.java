package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.model.Batch;
import com.cybage.model.Enrollment;
import com.cybage.model.Plans;
import com.cybage.model.Sports;
import com.cybage.model.Users;
import com.cybage.model.Users1;
import com.cybage.service.CustomerserviceImpl;

public class CustomerController extends HttpServlet {
	//public static final Logger logger = LogManager.getLogger(CustomerController.class.getName());
	private static final long serialVersionUID = 1L;
	
	CustomerserviceImpl Customerserviceobj=new CustomerserviceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		System.out.println(path);
		if(path.equals("/Registeruser")) {			
			PrintWriter out = response.getWriter();
			String Username=request.getParameter("uname");
			String Password =request.getParameter("pwd");
			String Role=request.getParameter("role");
			String Address =request.getParameter("addr");
			String Phone=request.getParameter("phone");
			String Email =request.getParameter("email");
			out.print("abccccc");
			try {
				if(Customerserviceobj.insertuser(Username, Password, Role,Address,Phone, Email))
				{
				out.println("you registered Successfully");
				//out.print("<a href='Login'>Login Here</a>"); ;
				RequestDispatcher rs = request.getRequestDispatcher("/Welcome.jsp");
				rs.forward(request, response);
				}else
				 {
				   out.println("registration fail");
				   //RequestDispatcher rs = request.getRequestDispatcher("Register.jsp");
				   //rs.include(request, response);
				 }
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
		
		if(path.equals("/displaysports")) {
			try {
				List<Sports> sports =  Customerserviceobj.displaysports();
				request.setAttribute("sports", sports);
				request.getRequestDispatcher("/member/member-sports.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}
		if(path.equals("/viewplans")) {
			try {
				List<Plans> plans =  Customerserviceobj.displayplans();
				request.setAttribute("plans", plans);
				request.getRequestDispatcher("/member/member-plan.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		if(path.equals("/viewbatches")) {
			try {
				System.out.println("in the batch");
				List<Batch> batch =  Customerserviceobj.displayBatches();
				request.setAttribute("batch", batch);
				request.getRequestDispatcher("/member/member-Batch.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if(path.equals("/viewEnrollment")) {
			try {
				//System.out.println("in the batch");
				List<Enrollment> user=  Customerserviceobj.displayEnroll(request.getRemoteUser());
				request.setAttribute("User", user);
				request.getRequestDispatcher("/member/member-Enrollment.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if(path.equals("/viewuserprofile")) {
			try {
				//System.out.println("in the batch");
				Users1 user=  Customerserviceobj.viewuser(request.getRemoteUser());
				request.setAttribute("User", user);
				request.getRequestDispatcher("/member/member-profile.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		if(path.equals("/edituser")) {			
			try {
				Users1 user = Customerserviceobj.viewuser(request.getParameter("username"));
				request.setAttribute("user", user);
				request.getRequestDispatcher("/member/update-user.jsp").forward(request, response);								
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/updateuser")) {			
			try {
				PrintWriter out = response.getWriter();
				Users1 user = new Users1();
				String userName=request.getParameter("uname");
				String password=request.getParameter("pwd");
				String role=request.getParameter("role");
				String address=request.getParameter("addr");
				String phone=request.getParameter("phone");
				String email=request.getParameter("email");
				System.out.println(password);
				System.out.println(role);
				System.out.println(phone);
				System.out.println(email);
				System.out.println(address);
				System.out.println(userName);
				Customerserviceobj.updateuser(userName,address,password,phone,email);
				//String msg = "your profile updated successfully..";
				//request.setAttribute("msg", msg);
				//response.sendRedirect("/member/update-user");	
				request.getRequestDispatcher("/member/update.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		
		if(path.equals("/updateEnrollment")) {
			try {
				PrintWriter out = response.getWriter();
				//System.out.println("in the batch");
				Enrollment enroll = new Enrollment();
				String Date= request.getParameter("startdate");
				out.print(Date);
				//enroll.setStartDate(LocalDate.parse(request.getParameter("startdate")));
				//(LocalDate.parse(request.getParameter("startdate"))
				LocalDate sdate=LocalDate.parse(request.getParameter("startdate"));
				System.out.println(sdate);
				LocalDate edate=LocalDate.parse(request.getParameter("enddate"));
				System.out.println(edate);
				
				sdate.plusMonths(1);
				 edate.plusMonths(1);
				if( Customerserviceobj.updateEnrollment(sdate,edate,request.getRemoteUser()))
				{
					out.print("you registered Successfully");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/displayBatchesbyplan")) {			
			try {
			
				List<Batch> batch  = Customerserviceobj.displayBatchesbyplan(Integer. parseInt(request. getParameter("planid")));	
				request.setAttribute("batch", batch);
				request.getRequestDispatcher("/member/member-Batch.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
		
 	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	}

//}

