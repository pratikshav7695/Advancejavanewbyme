package com.cybage.service;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import com.cybage.dao.CustomerDaoI;
import com.cybage.dao.CustomerDaoImpl;
import com.cybage.model.Batch;
import com.cybage.model.Enrollment;
import com.cybage.model.Plans;
import com.cybage.model.Sports;
import com.cybage.model.Users1;

public class CustomerserviceImpl implements CustomerserviceI {

	CustomerDaoI CustomerDaoObj=new CustomerDaoImpl();
	public Boolean validateuser(String username, String password) throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.validateuser(username,password);
	}
	public Boolean insertuser(String username, String password, String role, String address, String Phone, String email)
			throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.insertuser(username,  password,  role,  address,  Phone,  email);
	}
	public List<Sports> displaysports() throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.displaysports();
	}
	public List<Plans> displayplans() throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.displayplans();
	}
	public List<Batch> displayBatches() throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.displayBatches();
	}
	public List<Enrollment> displayEnroll(String username) throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.displayEnroll(username);
	}
	public Users1 viewuser(String username) throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.viewuser(username);
	}
	public boolean updateEnrollment(LocalDate sdate, LocalDate edate,String username) throws Exception {
		// TODO Auto-generated method stub
		
		return CustomerDaoObj.updateEnrollment(sdate,edate,username);
	}
	public int updateUser(Users1 user) throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.updateUser(user);
	}
	public List<Batch> displayBatchesbyplan(int planid) throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.displayBatchesbyplan(planid);
	}

	public boolean updateuser(String userName, String address, String password, String phone, String email)
			throws SQLException, Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.updateuser(userName,address,password,phone,email);
	}
	

}
