package com.cybage.service;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.cybage.model.Batch;
import com.cybage.model.Enrollment;
import com.cybage.model.Plans;
import com.cybage.model.Sports;
import com.cybage.model.Users1;

public interface CustomerserviceI {
	public Boolean validateuser(String username,String password) throws Exception;
	public Boolean insertuser(String username,String password,String role,String address,String Phone,String email) throws Exception;
	public List<Sports> displaysports() throws Exception;
	public List<Plans> displayplans() throws Exception;
	public List<Batch> displayBatches() throws Exception;
	public List<Enrollment> displayEnroll(String username) throws Exception;
	public Users1 viewuser(String username) throws Exception;
	public boolean updateEnrollment(LocalDate sdate, LocalDate edate,String username) throws Exception ;
	public int updateUser(Users1 user) throws Exception ;
	public List<Batch> displayBatchesbyplan(int planid)throws Exception ;
	public boolean updateuser(String userName, String address, String password, String phone, String email)
			throws SQLException, Exception ;
	
}
