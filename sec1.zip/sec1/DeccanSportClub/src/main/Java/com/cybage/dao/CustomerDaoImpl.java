package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cybage.dbutil.DbUtil;

public class CustomerDaoImpl implements CustomerDaoI {

	public Boolean validateuser(String name, String pass) throws Exception {
		// TODO Auto-generated method stub
		boolean st =false;
		try {
		String sql = "select Username,Password from users where username = ? and password=?";
		Connection con = DbUtil.getConnection();		
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, name);
		ps.setString(2, pass);
		ResultSet rs= ps.executeQuery();
		st = rs.next();
		return st;
		}
		catch(Exception e) {
            e.printStackTrace();
        }
        return st; 
		
}

	@Override
	public Boolean insertuser(String username, String password, String role, String address, String Phone, String email)
			throws Exception {
		String sql = "insert into users (username,password,role,address,Phone,email)values(?, ?, ?, ?,?,?)";
		Connection con = DbUtil.getConnection();		//new object
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1,username);
		ps.setString(2, password);
		ps.setString(3,role);
		ps.setString(4,address);
		ps.setString(5,Phone);
		ps.setString(6,email);

		if(ps.executeUpdate() == 1) {
			con.commit();			//customer + account will be committed
			ps.close(); 
			con.close();  
			return true;
		}
		else{ 
			con.rollback();
			ps.close(); 
			con.close(); 
			return false;
		}
	}

	@Override
	public Boolean dispalysports() throws Exception {
		// TODO Auto-generated method stub
		boolean st =false;
		try {
		String sql = "select batchId,startDate,endDate from batch inner join sports on batch.sportId=sports.sportId";
		Connection con = DbUtil.getConnection();		
		Statement ps = con.createStatement();
		ResultSet rs= ps.executeQuery(sql);
		while{rs.next()){
			int batchId	=rs.getInt();
			String startDate=rs.getdate());
			String endDate=rs.getDate()
			String sportId=rs.getInt();
			String sportName=rs.getString();
		
		}
		catch(Exception e) {
            e.printStackTrace();
        }
        return st; 
		
	}
}
