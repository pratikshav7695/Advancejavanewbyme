package com.cybage.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.services.AdminserviceI;
import com.cybage.services.AdminserviceImpl;
import com.cybage.services.CustomerserviceI;
import com.cybage.services.CustomerserviceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class CustomerServlet extends HttpServlet {
	
	CustomerserviceI Customerserviceobj=new CustomerserviceImpl();
    public CustomerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	PrintWriter out = response.getWriter();
	String Username=request.getParameter("uname");
	String Password =request.getParameter("pwd");
	try {
		if(Customerserviceobj.validateuser(Username, Password))
		{
		out.println("Welcome User");
		//HttpSession session = request.getSession(); /* Creating a new session*/
		//session.setAttribute("uname", Username); 
		//RequestDispatcher rs = request.getRequestDispatcher("Welcome.jsp");
		//rs.forward(request, response);
		}else
		 {
		   out.println("Username or Password incorrect");
		   RequestDispatcher rs = request.getRequestDispatcher("Register.jsp");
		   rs.include(request, response);
		 }
	} catch (ServletException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = resp.getWriter();
		String Username=req.getParameter("uname");
		String Password =req.getParameter("pwd");
		String Role=req.getParameter("role");
		String Address =req.getParameter("addr");
		String Phone=req.getParameter("phone");
		String Email =req.getParameter("email");
		try {
			if(Customerserviceobj.insertuser(Username, Password, Role,Address,Phone, Email))
			{
			out.println("you registered Successfully");
			//out.print("<a href='Login'>Login Here</a>"); ;
			//RequestDispatcher rs = req.getRequestDispatcher("Login.jsp");
			//rs.forward(req, resp);
			}else
			 {
			   out.println("registration fail");
			   //RequestDispatcher rs = request.getRequestDispatcher("Register.jsp");
			   //rs.include(request, response);
			 }
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
