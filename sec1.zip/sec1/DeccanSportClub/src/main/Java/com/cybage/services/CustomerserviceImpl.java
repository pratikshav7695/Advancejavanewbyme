package com.cybage.services;

import com.cybage.dao.AdminDaoI;
import com.cybage.dao.AdminDaoImpl;
import com.cybage.dao.CustomerDaoI;
import com.cybage.dao.CustomerDaoImpl;

public class CustomerserviceImpl implements CustomerserviceI {
	CustomerDaoI CustomerDaoObj=new CustomerDaoImpl();
	public Boolean validateuser(String username, String password) throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.validateuser(username,password);
	}
	@Override
	public Boolean insertuser(String username, String password, String role, String address, String Phone, String email)
			throws Exception {
		// TODO Auto-generated method stub
		return CustomerDaoObj.insertuser(username,  password,  role,  address,  Phone,  email);
	}

}
