package com.cybage.dao;

public interface CustomerDaoI {
public Boolean validateuser(String username,String password) throws Exception;
public Boolean insertuser(String username,String password,String role,String address,String Phone,String email)throws Exception;
public Boolean dispalysports()throws Exception;
}
