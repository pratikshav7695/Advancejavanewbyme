package com.cybage.services;

public interface AdminserviceI {
	public String showRole(String role) throws Exception;
	
}
