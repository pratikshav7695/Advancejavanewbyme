package com.cybage.services;

import com.cybage.dao.AdminDaoI;
import com.cybage.dao.AdminDaoImpl;

public class AdminserviceImpl implements AdminserviceI {
	AdminDaoI adminDaoObj=new AdminDaoImpl();
	public String showRole(String username) throws Exception {
		// TODO Auto-generated method stub
		return adminDaoObj.getRole(username);
	}


}
