package com.cybage.services;

public interface CustomerserviceI {
public Boolean validateuser(String username,String password) throws Exception;
public Boolean insertuser(String username,String password,String role,String address,String Phone,String email) throws Exception;
}
