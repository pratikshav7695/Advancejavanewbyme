package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.model.Users1;
import com.cybage.service.CustomerserviceImpl;

public class CustomerController extends HttpServlet {
	CustomerserviceImpl Customerserviceobj=new CustomerserviceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		System.out.println(" out listuser");
		if(path.equals("/listuser")) {	
			System.out.println("listuser");
			PrintWriter out = response.getWriter();
			String Username=request.getParameter("uname");
			String Password =request.getParameter("pwd");
			
				try {
					if(Customerserviceobj.validateuser(Username, Password))
					{
					System.out.println("Welcome User");
					//HttpSession session = request.getSession(); /* Creating a new session*/
					//session.setAttribute("uname", Username); 
					//RequestDispatcher rs = request.getRequestDispatcher("/member/Welcome.jsp");
					//rs.forward(request, response);
					//request.getRequestDispatcher("/member/Welcome.jsp").forward(request, response);
					
					}else
					 {
					   out.println("Username or Password incorrect");
					  // RequestDispatcher rs = request.getRequestDispatcher("member/Register.jsp");
					   //rs.forward(request, response);
					   response.sendRedirect("member/register.jsp");
					 }
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
	}
		
	//	}
		if(path.equals("/Registeruser")) {			
			PrintWriter out = response.getWriter();
			String Username=request.getParameter("uname");
			String Password =request.getParameter("pwd");
			String Role=request.getParameter("role");
			String Address =request.getParameter("addr");
			String Phone=request.getParameter("phone");
			String Email =request.getParameter("email");
			try {
				if(Customerserviceobj.insertuser(Username, Password, Role,Address,Phone, Email))
				{
				out.println("you registered Successfully");
				//out.print("<a href='Login'>Login Here</a>"); ;
				//RequestDispatcher rs = req.getRequestDispatcher("Login.jsp");
				//rs.forward(req, resp);
				}else
				 {
				   out.println("registration fail");
				   //RequestDispatcher rs = request.getRequestDispatcher("Register.jsp");
				   //rs.include(request, response);
				 }
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
		
 	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	}

//}

